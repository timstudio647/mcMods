"""Generate Hearthdeep's original structure templates for Minecraft Java 26.3.

Coordinates are block positions, +z points south. District templates start at the
north doorway. Air is explicit inside rooms; omitted positions preserve terrain.
Run with Python 3.10+ and nbtlib 2.0.4.
"""
import gzip
import io
from pathlib import Path

import nbtlib as n

OUT = Path(__file__).resolve().parents[1] / 'src/main/resources/data/hearthdeep/structure'
BRICK = 'stone_bricks'
DARK = 'deepslate_tiles'
RIB = 'polished_tuff'
TRIM = 'chiseled_tuff_bricks'
LAMP = 'ochre_froglight'
WOOD = 'stripped_spruce_log'
PLANK = 'spruce_planks'
DISTRICTS = {
    'wheat': ('green', '麦穗街', '梯田 / 集市'),
    'ember': ('orange', '炉火街', '锻坊 / 浴场'),
    'ink': ('cyan', '青墨街', '书库 / 舆图室'),
    'honey': ('yellow', '蜜灯街', '食堂 / 医务室'),
}


def ints(values):
    return n.List[n.Int](values)


def state(name, **props):
    return name, tuple(sorted((key, str(value)) for key, value in props.items()))


class Template:
    def __init__(self, w, h, d):
        self.w, self.h, self.d = w, h, d
        self.blocks = {}
        self.block_entities = {}
        self.entities = []

    def put(self, x, y, z, block, **props):
        assert 0 <= x < self.w and 0 <= y < self.h and 0 <= z < self.d, (x, y, z)
        self.blocks[x, y, z] = state(block, **props)
        self.block_entities.pop((x, y, z), None)

    def fill(self, x1, y1, z1, x2, y2, z2, block, **props):
        for y in range(y1, y2 + 1):
            for z in range(z1, z2 + 1):
                for x in range(x1, x2 + 1):
                    self.put(x, y, z, block, **props)

    def resident(self, x, z):
        assert self.blocks[x, 1, z][0] == 'air' and self.blocks[x, 2, z][0] == 'air'
        self.entities.append(n.Compound({
            'pos': n.List[n.Double]([x + 0.5, 1.0, z + 0.5]), 'blockPos': ints([x, 1, z]),
            'nbt': n.Compound({'id': n.String('minecraft:villager'), 'PersistenceRequired': n.Byte(1),
                               'VillagerData': n.Compound({'type': n.String('minecraft:plains'),
                                                           'profession': n.String('minecraft:none'),
                                                           'level': n.Int(1)})})}))

    def sign(self, x, y, z, lines, rotation=0):
        self.put(x, y, z, 'spruce_sign', rotation=rotation)
        self.block_entities[x, y, z] = n.Compound({
            'id': n.String('minecraft:sign'), 'is_waxed': n.Byte(1),
            'front_text': n.Compound({'messages': n.List[n.String]((lines + [''] * 4)[:4]),
                                      'color': n.String('white'), 'has_glowing_text': n.Byte(1)})})

    def chest(self, x, z, loot):
        self.put(x, 1, z, 'chest', facing='north')
        self.block_entities[x, 1, z] = n.Compound({'id': n.String('minecraft:chest'),
            'LootTable': n.String('minecraft:chests/village/village_' + loot)})

    def save(self, name):
        # Back the entire floor with masonry. Source water in the baths and
        # irrigation channels must stay contained even above a natural cave.
        self.blocks = {(x, y + 1, z): block for (x, y, z), block in self.blocks.items()}
        self.block_entities = {(x, y + 1, z): tag for (x, y, z), tag in self.block_entities.items()}
        for x in range(self.w):
            for z in range(self.d):
                self.blocks[x, 0, z] = state(DARK)
        for entity in self.entities:
            entity['pos'][1] = n.Double(float(entity['pos'][1]) + 1)
            entity['blockPos'][1] = n.Int(int(entity['blockPos'][1]) + 1)
        palette = {}
        entries = []
        for pos, block in sorted(self.blocks.items(), key=lambda b: (b[0][1], b[0][2], b[0][0])):
            index = palette.setdefault(block, len(palette))
            data = {'pos': ints(pos), 'state': n.Int(index)}
            if pos in self.block_entities:
                data['nbt'] = self.block_entities[pos]
            entries.append(n.Compound(data))
        states = []
        for block, props in palette:
            data = {'id': n.String('minecraft:' + block)}
            if props:
                data['properties'] = n.Compound({k: n.String(v) for k, v in props})
            states.append(n.Compound(data))
        root = n.File({'DataVersion': n.Int(5023), 'size': ints([self.w, self.h + 1, self.d]),
                       'palette': n.List[n.Compound](states), 'blocks': n.List[n.Compound](entries),
                       'entities': n.List[n.Compound](self.entities)})
        buf = io.BytesIO()
        root.write(buf)
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / (name + '.nbt')).write_bytes(gzip.compress(buf.getvalue(), mtime=0))


def shell(w, h, d):
    t = Template(w, h, d)
    for z in range(d):
        for x in range(w):
            edge = min(x, z, w - 1 - x, d - 1 - z)
            tile = 'polished_andesite' if (x // 3 + z // 3) % 2 else 'stone'
            t.put(x, 0, z, DARK if edge <= 1 else tile)
            t.put(x, h - 1, z, DARK)
            for y in range(1, h - 1):
                block = 'air'
                if edge == 0:
                    block = RIB if y in (1, h - 3) else BRICK
                elif edge <= 2 and y >= h - 1 - (3 - edge):
                    block = 'tuff_bricks'
                t.put(x, y, z, block)
    # Flush ceiling lights along both aisles; no fixtures to obstruct villagers.
    for x in range(3, w - 2, 5):
        for z in range(3, d - 2, 5):
            t.put(x, h - 1, z, LAMP)
            if h >= 10:
                t.put(x, 0, z, 'shroomlight')
    return t


def roof_light(t, x, y, z):
    t.put(x, y, z, 'iron_chain')
    t.put(x, y - 1, z, 'lantern', hanging='true')


def north_door(t, end=0):
    mid = t.w // 2
    t.fill(mid - 2, 1, end, mid + 2, 4, end, 'air')
    for x in (mid - 3, mid + 3):
        t.fill(x, 1, end, x, 4, end, RIB)
        t.put(x, 4, end, TRIM)
    t.fill(mid - 2, 5, end, mid + 2, 5, end, 'polished_tuff_slab')


def gate():
    t = Template(23, 49, 23)
    # Rotunda and ring promenade around the central stair.
    low = shell(23, 11, 23)
    t.blocks.update(low.blocks)
    north_door(t)
    north_door(t, 22)
    for x in (0, 22):
        t.fill(x, 1, 9, x, 4, 13, 'air')
    for x in (2, 20):
        for z in (2, 20):
            t.fill(x, 1, z, x, 8, z, 'polished_basalt')
            t.put(x, 5, z, LAMP)
    for x in (2, 20):
        t.put(x, 1, 8, 'bell', attachment='floor', facing='west')
    # A watertight stairwell. The lower four metres open into the rotunda.
    t.fill(4, 5, 4, 18, 35, 18, BRICK)
    t.fill(5, 5, 5, 17, 35, 17, 'air')
    t.fill(8, 0, 8, 14, 35, 14, 'tuff_bricks')
    for h in (3, 10, 17, 24, 31):
        for x, z in ((11, 8), (14, 11), (11, 14), (8, 11)):
            t.put(x, h, z, LAMP)
    # Broad stair flights turn clockwise around the masonry core.
    corners = [(5, 5), (15, 5), (15, 15), (5, 15)]
    facings = ['east', 'south', 'west', 'north']
    for flight in range(6):
        x, z = corners[flight % 4]
        y = 7 * flight
        t.fill(x, y, z, x + 2, y, z + 2, 'polished_andesite')
        if flight == 5:
            break
        for step in range(7):
            level = y + step + 1
            for lane in range(3):
                sx, sz = [(8 + step, 5 + lane), (15 + lane, 8 + step),
                          (14 - step, 15 + lane), (5 + lane, 14 - step)][flight % 4]
                t.put(sx, level - 1, sz, RIB)
                t.put(sx, level, sz, 'stone_brick_stairs', facing=facings[flight % 4])
    # The surface pavilion stands on a battered plinth with four open arches.
    for x in range(23):
        for z in range(23):
            r = max(abs(x - 11), abs(z - 11))
            if r >= 7:
                t.fill(x, 32, z, x, 35, z, 'tuff_bricks')
                t.put(x, 35, z, RIB if r in (7, 10) else 'polished_andesite')
            t.fill(x, 36, z, x, 45, z, 'air')
            if r == 7 and not (x == 18 and 5 <= z <= 7) and not (z == 4 and 15 <= x <= 17):
                t.put(x, 36, z, 'stone_brick_wall')
    # Chamfered piers and a tiered weathered-copper roof, open at ground level.
    for x in (2, 20):
        for z in (2, 20):
            t.fill(x - 1, 36, z - 1, x + 1, 36, z + 1, 'tuff_bricks')
            t.fill(x, 37, z, x, 41, z, 'polished_basalt')
            t.put(x, 39, z, LAMP)
            t.fill(x - 1, 41, z - 1, x + 1, 41, z + 1, 'chiseled_tuff_bricks')
    for y, inset, mat in ((42, 0, 'deepslate_tile_slab'), (43, 2, 'waxed_exposed_cut_copper'),
                          (44, 4, 'waxed_weathered_cut_copper'), (45, 6, 'waxed_oxidized_cut_copper'),
                          (46, 8, 'deepslate_tiles')):
        t.fill(inset, y, inset, 22 - inset, y, 22 - inset, mat)
    t.fill(10, 47, 10, 12, 47, 12, 'ochre_froglight')
    t.fill(10, 48, 10, 12, 48, 12, 'waxed_weathered_cut_copper_slab')
    for x, z in ((11, 2), (2, 11), (20, 11), (11, 20)):
        roof_light(t, x, 41, z)
    t.sign(19, 36, 8, ['炉下城', '沿石梯下行', 'Hearthdeep', '↓'], rotation=8)
    t.save('gate_and_stair')


def street(key, color, name, subtitle):
    t = shell(11, 9, 27)
    north_door(t)
    north_door(t, 26)
    for x in (0, 10):
        t.fill(x, 1, 16, x, 4, 20, 'air')
    for z in range(1, 26):
        t.put(5, 0, z, 'cut_copper' if z % 4 == 0 else color + '_terracotta')
    for z in (3, 9, 15, 22):
        for x in (1, 9):
            t.fill(x, 1, z, x, 5, z, RIB)
            t.put(x, 3, z, LAMP)
            t.put(x, 5, z, TRIM)
        t.fill(2, 6, z, 8, 6, z, WOOD, axis='x')
        roof_light(t, 5, 5, z)
    t.sign(3, 1, 2, [name, subtitle, '〈 炉下城 〉'], rotation=8)
    t.save('street_' + key)


def side_room():
    t = shell(17, 8, 16)
    north_door(t)
    for x in (1, 15):
        for z in (3, 8, 13):
            t.fill(x, 1, z, x, 4, z, WOOD)
            t.put(x, 3, z, LAMP)
    return t


def homes(key, color):
    t = side_room()
    for z in (4, 9, 13):
        for x, step, facing in ((4, -1, 'west'), (12, 1, 'east')):
            t.put(x, 1, z, color + '_bed', facing=facing, part='foot')
            t.put(x + step, 1, z, color + '_bed', facing=facing, part='head')
            t.put(x + 2 * step, 1, z, PLANK)
            t.put(x + 2 * step, 2, z, 'lantern')
    for z in (6, 11):
        for xa, xb in ((2, 5), (11, 14)):
            t.fill(xa, 1, z, xb, 2, z, PLANK)
            t.put(xa, 3, z, 'potted_fern')
    t.fill(7, 1, 3, 9, 1, 12, color + '_carpet')
    t.chest(14, 2, 'plains_house')
    t.resident(6, 4)
    t.resident(10, 10)
    t.save('homes_' + key)


def terminal():
    t = shell(25, 11, 23)
    north_door(t)
    for z in (4, 11, 18):
        for x in (2, 22):
            t.fill(x, 1, z, x, 7, z, 'tuff_bricks')
            t.put(x, 4, z, LAMP)
            t.put(x, 7, z, TRIM)
        t.fill(3, 8, z, 21, 8, z, WOOD, axis='x')
        for x in (6, 12, 18):
            roof_light(t, x, 7, z)
    return t


def farm():
    t = terminal()
    for start, crop in ((3, 'wheat'), (15, 'carrots')):
        for z in range(4, 19):
            for x in range(start, start + 7):
                if x == start + 3:
                    t.put(x, 0, z, 'water', level=0)
                    t.put(x, 1, z, 'lily_pad')
                else:
                    t.put(x, 0, z, 'farmland', moisture=7)
                    t.put(x, 1, z, crop, age=7)
        # Grow lights sit close enough to keep the underground field productive.
        for x in (start + 1, start + 5):
            for z in (5, 10, 15, 18):
                t.put(x, 3, z, 'ochre_froglight')
                t.fill(x, 4, z, x, 8, z, 'iron_chain')
    t.put(10, 1, 19, 'composter')
    t.put(14, 1, 19, 'composter')
    t.chest(17, 20, 'plains_house')
    t.resident(11, 17)
    t.save('farm')


def forge():
    t = terminal()
    for x in (4, 10, 16):
        t.fill(x, 1, 18, x + 3, 5, 20, 'deepslate_bricks')
        t.fill(x + 1, 4, 19, x + 2, 9, 20, 'polished_basalt')
        t.put(x + 1, 2, 18, 'shroomlight')
        t.put(x + 1, 1, 18, 'blast_furnace', facing='north')
        t.put(x + 2, 1, 18, 'furnace', facing='north')
    for z in (5, 11):
        t.put(5, 1, z, 'smithing_table')
        t.put(8, 1, z, 'anvil')
        t.put(17, 1, z, 'grindstone', face='floor', facing='north')
        t.put(19, 1, z, 'water_cauldron', level=3)
    t.chest(21, 19, 'toolsmith')
    t.resident(12, 14)
    t.save('forge')


def library():
    t = terminal()
    for x in (4, 8, 16, 20):
        for za, zb in ((5, 9), (13, 18)):
            t.fill(x, 1, za, x, 4, zb, 'bookshelf')
            t.fill(x, 5, za, x, 5, zb, 'spruce_slab')
    for x in (10, 14):
        t.put(x, 1, 17, 'lectern', facing='north')
    t.fill(11, 1, 3, 13, 1, 14, 'cyan_carpet')
    t.chest(5, 20, 'cartographer')
    t.resident(11, 15)
    t.save('library')


def dining():
    t = terminal()
    for z in (5, 11):
        for xa, xb in ((4, 9), (15, 20)):
            t.fill(xa, 1, z, xb, 1, z, 'spruce_slab', type='top')
            for x in range(xa, xb + 1, 2):
                t.put(x, 1, z - 1, 'spruce_stairs', facing='north')
                t.put(x, 1, z + 1, 'spruce_stairs', facing='south')
            t.put(xa + 2, 2, z, 'candle', candles=3, lit='true')
    t.fill(3, 1, 19, 21, 1, 19, 'bricks')
    for x in (5, 8, 16, 19):
        t.put(x, 1, 19, 'smoker', facing='north')
    t.put(12, 2, 19, 'cake')
    t.put(10, 2, 19, 'lantern')
    t.chest(20, 17, 'butcher')
    t.resident(13, 15)
    t.save('refectory')


def services():
    t = side_room()
    for x in (3, 11):
        t.fill(x, 1, 7, x + 2, 1, 10, PLANK)
        for z in (7, 10):
            t.fill(x, 2, z, x, 3, z, 'oak_fence')
        for dx in range(4):
            t.fill(x + dx, 4, 6, x + dx, 4, 11, 'green_wool' if dx % 2 else 'white_wool')
    t.put(4, 2, 8, 'melon')
    t.put(12, 2, 8, 'pumpkin')
    t.put(4, 1, 13, 'barrel')
    t.chest(12, 13, 'plains_house')
    t.save('market')

    t = side_room()
    for x in (3, 10):
        t.fill(x, 0, 5, x + 3, 0, 11, 'water', level=0)
        t.fill(x, 0, 4, x + 3, 0, 4, 'prismarine_bricks')
        t.fill(x, 0, 12, x + 3, 0, 12, 'prismarine_bricks')
    t.put(7, 1, 13, 'water_cauldron', level=3)
    t.put(9, 1, 13, 'water_cauldron', level=3)
    t.save('bath')

    t = side_room()
    t.fill(3, 1, 11, 13, 1, 12, 'dark_oak_planks')
    for x in (5, 11):
        t.put(x, 1, 11, 'cartography_table')
    for x in (2, 14):
        t.fill(x, 1, 5, x, 3, 9, 'bookshelf')
    t.chest(3, 13, 'cartographer')
    t.save('map_room')

    t = side_room()
    for x in (3, 12):
        for z in (5, 9):
            t.put(x, 1, z, 'white_bed', facing='south', part='foot')
            t.put(x, 1, z + 1, 'white_bed', facing='south', part='head')
    t.fill(5, 1, 13, 11, 1, 13, 'smooth_quartz')
    t.put(6, 2, 13, 'brewing_stand')
    t.put(10, 2, 13, 'potted_lily_of_the_valley')
    t.put(11, 1, 12, 'water_cauldron', level=3)
    t.save('infirmary')


if __name__ == '__main__':
    gate()
    for key, (color, name, subtitle) in DISTRICTS.items():
        street(key, color, name, subtitle)
        homes(key, color)
    farm()
    forge()
    library()
    dining()
    services()
