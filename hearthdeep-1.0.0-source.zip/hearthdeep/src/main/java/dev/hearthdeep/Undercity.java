package dev.hearthdeep;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePiecesBuilder;
import net.minecraft.world.level.levelgen.structure.pools.StructurePoolElement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;
import net.minecraft.world.level.levelgen.structure.templatesystem.LiquidSettings;

public final class Undercity extends Structure {
    static final MapCodec<Undercity> CODEC = simpleCodec(Undercity::new);
    private static final int STAIR_RISE = 35;
    private static final Rotation[] DIRECTIONS = {
        Rotation.NONE, Rotation.CLOCKWISE_90, Rotation.CLOCKWISE_180, Rotation.COUNTERCLOCKWISE_90
    };
    private static final String[][] WINGS = {
        {"wheat", "farm", "market"}, {"ember", "forge", "bath"},
        {"ink", "library", "map_room"}, {"honey", "refectory", "infirmary"}
    };

    private Undercity(StructureSettings settings) {
        super(settings);
    }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext ctx) {
        if (!ctx.couldValidBiomeExistOnTopOfChunkCenter()) return Optional.empty();
        int x = ctx.chunkPos().getMiddleBlockX();
        int z = ctx.chunkPos().getMiddleBlockZ();
        int grade = height(ctx, x, z, Heightmap.Types.WORLD_SURFACE_WG);
        int floor = grade - STAIR_RISE;
        if (floor < ctx.heightAccessor().getMinY() + 5 || grade + 13 > ctx.heightAccessor().getMaxY()) {
            return Optional.empty();
        }
        // Check the gate footprint against both heightmaps to avoid deep water and steep banks.
        for (int dx = -11; dx <= 11; dx += 11) {
            for (int dz = -11; dz <= 11; dz += 11) {
                int ground = height(ctx, x + dx, z + dz, Heightmap.Types.OCEAN_FLOOR_WG);
                int surface = height(ctx, x + dx, z + dz, Heightmap.Types.WORLD_SURFACE_WG);
                if (surface != ground || Math.abs(grade - ground) > 2) return Optional.empty();
            }
        }
        // Give the vaulted ceilings cover even where a nearby valley falls below the gate.
        for (Rotation direction : DIRECTIONS) {
            for (int distance : new int[]{30, 60}) {
                for (int lateral : new int[]{-16, 0, 16}) {
                    BlockPos offset = new BlockPos(lateral, 0, distance).rotate(direction);
                    int y = height(ctx, x + offset.getX(), z + offset.getZ(), Heightmap.Types.OCEAN_FLOOR_WG);
                    if (y < floor + 14) return Optional.empty();
                }
            }
        }
        BlockPos entrance = new BlockPos(x, grade, z);
        return Optional.of(new GenerationStub(entrance,
                builder -> assemble(ctx, builder, entrance.below(STAIR_RISE))));
    }

    private static int height(GenerationContext ctx, int x, int z, Heightmap.Types type) {
        return ctx.chunkGenerator().getFirstOccupiedHeight(x, z, type, ctx.heightAccessor(), ctx.randomState());
    }

    private static void assemble(GenerationContext ctx, StructurePiecesBuilder builder, BlockPos center) {
        Rotation orientation = DIRECTIONS[ctx.random().nextInt(4)];
        piece(ctx, builder, center, orientation, -11, -11, Rotation.NONE, "gate_and_stair");
        // A seeded shuffle assigns each of the four districts exactly once.
        String[][] districts = WINGS.clone();
        for (int i = districts.length - 1; i > 0; --i) {
            int j = ctx.random().nextInt(i + 1);
            String[] swap = districts[i];
            districts[i] = districts[j];
            districts[j] = swap;
        }
        for (int i = 0; i < DIRECTIONS.length; i++) {
            Rotation wing = orientation.getRotated(DIRECTIONS[i]);
            String[] district = districts[i];
            piece(ctx, builder, center, wing, -5, 12, Rotation.NONE, "street_" + district[0]);
            piece(ctx, builder, center, wing, -12, 39, Rotation.NONE, district[1]);
            boolean homesOnLeft = ctx.random().nextBoolean();
            String homes = "homes_" + district[0];
            piece(ctx, builder, center, wing, -6, 22, Rotation.CLOCKWISE_90,
                    homesOnLeft ? homes : district[2]);
            piece(ctx, builder, center, wing, 6, 38, Rotation.COUNTERCLOCKWISE_90,
                    homesOnLeft ? district[2] : homes);
        }
    }

    private static void piece(GenerationContext ctx, StructurePiecesBuilder builder, BlockPos center,
                              Rotation wing, int x, int z, Rotation turn, String template) {
        BlockPos origin = center.offset(new BlockPos(x, -1, z).rotate(wing));
        Rotation rotation = wing.getRotated(turn);
        var element = StructurePoolElement.single("hearthdeep:" + template)
                .apply(StructureTemplatePool.Projection.RIGID);
        var templates = ctx.structureTemplateManager();
        builder.addPiece(new PoolElementStructurePiece(templates, element, origin, 0, rotation,
                element.getBoundingBox(templates, origin, rotation), LiquidSettings.IGNORE_WATERLOGGING));
    }

    @Override
    public StructureType<?> type() {
        return Hearthdeep.UNDERCITY;
    }
}
