package dev.hearthdeep;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.levelgen.structure.StructureType;

public final class Hearthdeep implements ModInitializer {
    static final StructureType<Undercity> UNDERCITY = () -> Undercity.CODEC;

    @Override
    public void onInitialize() {
        Registry.register(BuiltInRegistries.STRUCTURE_TYPE,
                Identifier.fromNamespaceAndPath("hearthdeep", "undercity"), UNDERCITY);
    }
}
