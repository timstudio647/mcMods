"""Build the Fabric jar with JDK 25 and Python 3.10+. No Gradle or mappings required."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.request import urlopen
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
CACHE = BUILD / 'cache'
SERVER_URL = 'https://piston-data.mojang.com/v1/objects/33680f5f2ac32864d6d7cf5e56a705fdb3e05f4c/server.jar'
LOADER_URL = 'https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.20.1/fabric-loader-0.20.1.jar'


def download(name, url, sha256):
    path = CACHE / name
    if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == sha256:
        return path
    with urlopen(url, timeout=120) as response:
        data = response.read()
    if hashlib.sha256(data).hexdigest() != sha256:
        raise RuntimeError(f'{name}: download checksum mismatch')
    path.write_bytes(data)
    return path


def main():
    CACHE.mkdir(exist_ok=True, parents=True)
    javac = shutil.which('javac')
    if not javac:
        raise SystemExit('Install JDK 25 and add its bin directory to PATH.')
    server = download('server.jar', SERVER_URL, 'd052f14d7a173734fba553711e5b570162e2f2a313267ee31a21b975a679be64')
    loader = download('fabric-loader.jar', LOADER_URL, 'd0c5a082e07410aaff9de7ab196aa6b4236002870f9ba3ad5c1260fcce5110ad')
    with tempfile.TemporaryDirectory(dir=BUILD) as staging:
        temp = Path(staging)
        deps = temp / 'deps'
        deps.mkdir()
        with ZipFile(server) as bundle:
            for entry in bundle.namelist():
                if entry.startswith(('META-INF/libraries/', 'META-INF/versions/')) and entry.endswith('.jar'):
                    (deps / Path(entry).name).write_bytes(bundle.read(entry))
        classes = temp / 'classes'
        classes.mkdir()
        cp = os.pathsep.join(map(str, [deps / '*', loader]))
        files = sorted((ROOT / 'src/main/java').rglob('*.java'))
        subprocess.run([javac, '--release', '25', '-encoding', 'UTF-8', '-cp', cp,
                        '-d', str(classes), *map(str, files)], check=True)
        output = BUILD / 'libs/hearthdeep-1.0.0+mc26.3.jar'
        output.parent.mkdir(exist_ok=True)
        staged = temp / output.name
        with ZipFile(staged, 'w') as jar:
            for folder in (classes, ROOT / 'src/main/resources'):
                for path in sorted(folder.rglob('*')):
                    if path.is_file():
                        info = ZipInfo(path.relative_to(folder).as_posix(), (2026, 9, 15, 0, 0, 0))
                        jar.writestr(info, path.read_bytes(), compress_type=ZIP_DEFLATED)
        staged.replace(output)
        print(output)


if __name__ == '__main__':
    main()
